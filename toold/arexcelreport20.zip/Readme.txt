======================================
      ARExcelReport Delphi component.

	Author        : Anton Ryazanov
	Version       : 2.0
	Copyright     : Anton Ryazanov

	Description   : ARExcelReport component

        Simple and powerful report generation with Micrisoft� Excel.

	ARExcelReport component designed to provide easy way for reports generation in Microsoft� Excel.
	It is comfortable for use and may be used as a main or complementary reporting tool in your projects.
	Thanks to the original ideas ARExcelReport is fast enough and gives software developers and users
	rich abilities to create reports easy in transportable format.

        Highlights:

         � Simple report templates creation direct in MS Excel
	   using its full formatting abilities.
         � Passing data into report by different ways including
           named text parameters, datasets and OnTag event.
         � Database engine independent.
         � Conditional blocks in report template.
         � Custom SQL Queries in report template.
         � Custom macros and interactive elements in report. 

	Environment   : Delphi 3,4,5,6,7,2005,2006,2007,2009,2010, C++Builder 5,6,2009.
	Compatibility : MS Excel 97, 2000, XP, 2003, 2007.
	E-Mail        : vsoft@vector-ski.ru
	WebSite       : http://www.vector-ski.com/reports

	License type  : Freeware for non-commercial use. 

=====================================================
Installation:

1) Uninstal any previously installed version of ARExcelReport form Delphi
(Delphi Menu - Components - Install Packages.. then select
"ARExcelReport" and press "Remove" button).
2) Close Delphi.
3) Install ARExcelReport by executing arexcelreport**.exe.
4) Run Delphi.
========================================================================

