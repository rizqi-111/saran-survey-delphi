<script src="plugin/bootstrap/js/chart-master/Chart.js"></script>
<script src="plugin/bootstrap/js/chart-master/legend.js"></script>
<script>
if(!!(window.addEventListener)) window.addEventListener('DOMContentLoaded', main);
else window.attachEvent('onload', main);


function main() {

}
</script>
	<head>
		
		<meta name = "viewport" content = "initial-scale = 1, user-scalable = no">
		<style>
			canvas{
			}
		</style>
	</head>
	<body>
<?PHP  
include_once'plugin.php';

/* include'config/database.php';
include'objects/survey.php';
  
// instantiate database class
$database = new Database();
$db = $database->getConnection();
  
// initialize object
$survey = new Survey($db); */



$x=$survey->gethasilnrr();
$decode = json_decode($x, true);
//var_dump($decode);
/* foreach($decode['data'] as $row){
	echo $row['l'];echo $row['p']."<br>";
} */
$i=0;$xx='';$xt='';
foreach($decode['data'] as $row){
	$i++;
	
	if ($i<14){
	//$xx=$xx.number_format($row['nrr'],2).",(".$i.")";	
	$xx=$xx.number_format($row['nrr'],2).",";
	$xt=$xt.number_format($row['nrrt'],2).",";
	//$xy=$xy.'"'.$row['unsur'].",";
	} else{
	$xx=$xx.number_format($row['nrr'],2);
	//echo $xx;
    $xt=$xt.number_format($row['nrrt'],2);
    //$xy=$xy.$row['unsur'];	
	}

}
$xy='"Prosedur pelayanan","Persyaratan pelayanan","Kejelasan petugas pelayanan",
"Kedisiplinan petugas pelayanan","Tanggung jawab petugas pelayanan",
"Kemampuan petugas pelayanan","Kecepatan pelayanan","Keadilan mendapatkan pelayanan",
"Kesopanan dan keramahan petugas","Kewajaran biaya pelayanan",
"Kepastian biaya pelayanan","Kepastian jadwal pelayanan","Kenyamanan lingkungan",
"Keamanan pelayanan"';

?>		  
					  

	<canvas id="canvas" height="450" width="600"></canvas>


	<script>

		var barChartData = {
			labels : [<?php echo $xy?>],
			datasets : [
				{
					fillColor : "rgba(255,51,0,0.5)",
					strokeColor : "rgba(255,102,102,1)",
					data : [<?php echo $xx?>]
				},
				{
					fillColor : "rgba(0,51,255,0.5)",
					strokeColor : "rgba(102,102,255,1)",
					data : [<?php echo $xt?>]
				}
			]
			
		}

	var myLine = new Chart(document.getElementById("canvas").getContext("2d")).Bar(barChartData);
	
	</script>
	</body>
</html>
