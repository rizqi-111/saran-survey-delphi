<?PHP
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title>Login</title>


    <link href="plugin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="plugin/bootstrap/css/bootstrap-reset.css" rel="stylesheet">
    <link href="plugin/bootstrap/css/font-awesome.css" rel="stylesheet" />
    <link href="plugin/bootstrap/css/style.css" rel="stylesheet">
    <link href="plugin/bootstrap/css/style-responsive.css" rel="stylesheet" />

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
    <!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->
  </head>

 <body class="lock-screen" onload="startTime()">
<div id='page-content'>
		
</div>
    <div class="lock-wrapper">
        <div id="time"></div>
		<div class="lock-box text-center">
            <img src="img/follower-avatar.png" alt="lock avatar"/>
            <h1 class="locked">BVet Lampung</h1><br>
            <span class="locked">IKM System Management</span>
            <form role="form" class="form-inline" action="hasil.html" onSubmit="return validasi(this)">
                <div class="form-group col-lg-12">
				<input type="password" class="form-control lock-input" id="cpassword" name="password" placeholder="Password" required></input>				
                    <button id="login" class="btn btn-danger" type="submit"> <i class=" icon-ok"></i></button>
                </div><br>
            </form>
        </div>
        <br>
        <a href="index.php" class="btn btn-primary" id="btn-back" style='width: 330px;'>kembali</a>
    </div>
	

<a class="btn btn-primary" data-toggle="modal" href='#modal-id' id="sembunyi">Trigger modal</a>
<!-- modal -->
<div class="modal fade" id="modal-id" data-keyboard="false" data-backdrop="static" style='margin-top: 0px;'>
<div class="row">
<div class="col-lg-4"></div>
<div class="col-lg-4">
<div class="panel-body">
  <div class="alert alert-danger alert-block fade in" style='margin-top: 250px;'>
  <button data-dismiss="modal" class="close close-sm" id="btn-close" type="button">
  <i class="icon-close"></i>
  </button>
  <h4 style=''>
  <i class="icon-remove"></i>
  Kesalahan !
  </h4><hr>
  <p><strong>Password</strong> anda tidak diterima, silahkan hubungi operator jika anda mengalami kesulitan.</p>
 </div>	 </div> </div>
</div></div>
<!-- modal -->	
	



	
<script>
        function startTime()
        {
            var today=new Date();
            var h=today.getHours();
            var m=today.getMinutes();
            var s=today.getSeconds();
            // add a zero in front of numbers<10
            m=checkTime(m);
            s=checkTime(s);
            document.getElementById('time').innerHTML=h+":"+m+":"+s;
			document.getElementById('sembunyi').style.visibility = 'hidden';
            t=setTimeout(function(){startTime()},500);
        }

        function checkTime(i)
        {
            if (i<10)
            {
                i="0" + i;
            }
            return i;
        }
		

function validasi(form){
     
  if (form.password.value == "bostrigun"){
  return (true);  
  }
  form.password.focus();
  document.getElementById('sembunyi').click();

            setInterval(function(){ 
			    document.getElementById("btn-close").click();
			}, 3000);
  return (false);
  
}

$('#btn-back').click(function(){
  window.location='index.php';
});
</script>
		
    <script src="plugin/bootstrap/js/jquery.js"></script>
    <script src="plugin/bootstrap/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="plugin/bootstrap/js/jquery.validate.min.js"></script>

    <script src="plugin/bootstrap/js/form-validation-script.js"></script>
	</body>
</html>
