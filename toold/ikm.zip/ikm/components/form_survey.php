<!-- <link rel="stylesheet" href="plugin/bootstrap/css/svy.css"> -->
<div class="container">
  <div class="row">
    <section>
        <div class="wizard">
            <div class="wizard-inner">
                <div class="connecting-line"></div>
                <ul class="nav nav-tabs" role="tablist">

                    <li role="presentation" class="active">
                        <a href="#step1" data-toggle="tab" aria-controls="step1" role="tab" title="Step 1">
                            <span class="round-tab">
                                <i class="icon-user"></i>
                            </span>
                        </a>
                    </li>

                    <li role="presentation" class="disabled">
                        <a href="#step2" data-toggle="tab" aria-controls="step2" role="tab" title="Step 2">
                            <span class="round-tab">
                                <i class="icon-check"></i>
                            </span>
                        </a>
                    </li>
                    <li role="presentation" class="disabled">
                        <a href="#step3" data-toggle="tab" aria-controls="step3" role="tab" title="Step 3">
                            <span class="round-tab">
                                <i class="icon-check"></i>
                            </span>
                        </a>
                    </li>
                    <li role="presentation" class="disabled">
                        <a href="#step4" data-toggle="tab" aria-controls="step3" role="tab" title="Step 4">
                            <span class="round-tab">
                                <i class="icon-check"></i>
                            </span>
                        </a>
                    </li>
                </ul>
            </div>
          <div class="col-xs-9 col-sm-9 col-md-9 col-lg-9 col-md-offset-1" style='margin-left: 150px'>
            <form role="form" class="form-horizontal" id="insert-survey" method="post">
                <div class="tab-content">
                    <div class="tab-pane active" role="tabpanel" id="step1">
                        <h3>Data Responden</h3>
                        <br>
                        <div class="form-group">
                          <label class="col-md-3 control-label" for="name">Umur</label>
                          <div class="col-md-3">
                            <input id="umur" name="umur" min="15" type="number" placeholder="Masukkan Umur Anda" class="form-control">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-3 control-label" for="name">Jenis Kelamin</label>
                          <div class="col-md-9">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm active" data-toggle="jkl" data-title="L">Laki-Laki</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="jkl" data-title="P">Perempuan</a>
                              </div>
                              <input type="hidden" name="jkl" id="jkl">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-3 control-label" for="name">Pendidikan Terakhir</label>
                          <div class="col-md-9">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pdkn" data-title="SD ke bawah">SD ke bawah</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pdkn" data-title="SLTP">SLTP</a>
                                <a class="btn btn-primary btn-sm active" data-toggle="pdkn" data-title="SLTA">SLTA</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pdkn" data-title="D1-D2--D4">D1-D2--D4</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pdkn" data-title="S1">S1</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pdkn" data-title="S2 ke atas">S2 ke atas</a>
                              </div>
                              <input type="hidden" name="pdkn" id="pdkn">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-3 control-label" for="name">Pekerjaan Utama</label>
                          <div class="col-md-9">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pkrjn" data-title="PNS/TNI/POLRI">PNS/TNI/POLRI</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pkrjn" data-title="Pegawai Swasta">Pegawai Swasta</a>
                                <a class="btn btn-primary btn-sm active" data-toggle="pkrjn" data-title="Wiraswasta">Wiraswasta</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pkrjn" data-title="Pelajar/Mahasiswa">Pelajar/Mahasiswa</a>
                                <a class="btn btn-primary btn-sm notActive" data-toggle="pkrjn" data-title="Lainnya">Lainnya</a>
                              </div>
                              <input type="hidden" name="pkrjn" id="pkrjn">
                            </div>
                          </div>
                        </div>
                        <br>
                        <br>
                        <div class="form-group">
                          <div class="col-md-12 text-right">
                            <button type="button" class="btn btn-lg btn-primary next-step"><i class="icon-chevron-sign-right" id="btn-step1"></i> Selanjutnya</button>
                          </div>
                        </div>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="step2">
                        <h3>Pendapat Anda Tentang Pelayanan Kami ?</h3>
                        <br>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Prosedur pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv1" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv1" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv1" id="baik1" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv1" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv1" id="sv1">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Persyaratan pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv2" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv2" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv2" id="baik2" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv2" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv2" id="sv2">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kejelasan petugas pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv3" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv3" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv3" id="baik3" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv3" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv3" id="sv3">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kedisiplinan petugas pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv4" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv4" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv4" id="baik4" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv4" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv4" id="sv4">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Tanggung jawab petugas pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv5" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv5" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv5" id="baik5" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv5" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv5" id="sv5">
                            </div>
                          </div>
                        </div>
                        <br><br>
                        <div class="form-group">
                          <div class="col-md-12 text-right">
                            <button type="button" class="btn btn-lg btn-default prev-step"><i class="icon-chevron-sign-left"></i> Sebelumnya</button>
                            <button type="button" class="btn btn-lg btn-primary next-step"><i class="icon-chevron-sign-right"></i> Selanjutnya</button>
                          </div>
                        </div>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="step3">
                        <h3>Pendapat Anda Tentang Pelayanan Kami ?</h3>
                        <br>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kemampuan petugas pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv6" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv6" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv6" id="baik6" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv6" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv6" id="sv6">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kecepatan pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv7" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv7" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv7" id="baik7" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv7" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv7" id="sv7">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Keadilan mendapatkan pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv8" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv8" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv8" id="baik8" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv8" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv8" id="sv8">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kesopanan dan keramahan petugas </label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv9" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv9" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv9" id="baik9" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv9" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv9" id="sv9">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name"> Kewajaran biaya pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv10" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv10" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv10" id="baik10" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv10" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv10" id="sv10">
                            </div>
                          </div>
                        </div>
                        <br><br>
                        <div class="form-group">
                          <div class="col-md-12 text-right">
                            <button type="button" class="btn btn-lg btn-default prev-step"><i class="icon-chevron-sign-left"></i> Sebelumnya</button>
                            <button type="button" class="btn btn-lg btn-primary next-step"><i class="icon-chevron-sign-right"></i> Selanjutnya</button>
                          </div>
                        </div>
                    </div>
                    <div class="tab-pane" role="tabpanel" id="step4">
                        <h3>Pendapat Anda Tentang Pelayanan Kami ?</h3>
                        <br>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kepastian biaya pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv11" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv11" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv11" id="baik11" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv11" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv11" id="sv11">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Kepastian jadwal pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv12" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv12" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv12" id="baik12" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv12" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv12" id="sv12">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name"> Kenyamanan lingkungan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv13" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv13" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv13" id="baik13" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv13" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv13" id="sv13">
                            </div>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="col-md-4 control-label" for="name">Keamanan pelayanan</label>
                          <div class="col-md-8">
                            <div class="input-group">
                              <div id="radioBtn" class="btn-group">
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv14" data-title="1">Sangat
Kurang</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv14" data-title="2">Kurang</a>
                                <a class="btn btn-primary btn-sm active srv" data-toggle="sv14" id="baik14" data-title="3">Baik</a>
                                <a class="btn btn-primary btn-sm notActive srv" data-toggle="sv14" data-title="4">Sangat Baik</a>
                              </div>
                              <input type="hidden" name="sv14" id="sv14">
                            </div>
                          </div>
                        </div>
                        <br><br>
                        <div class="form-group">
                          <div class="col-md-12 text-right">
                            <button type="button" class="btn btn-lg btn-default prev-step"><i class="icon-chevron-sign-left"></i> Sebelumnya</button>
                            <button type="submit" class="btn btn-lg btn-success next-step"><i class="icon-check"></i> Selesai</button>
                            <!-- <a type="submit" class="btn btn-lg btn-success next-step" data-toggle="modal" id="mdl" href='#modal-id'><span class="blink_me"><i class="fa fa-check"></i> Selesai</span></a> -->
                          </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </form>
          </div>
        </div>
    </section>
   </div>
</div>

<!-- modal -->
<!-- <div class="modal fade" id="modal-id" data-keyboard="false" data-backdrop="static" style='margin-top: 200px;'>
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-body">
        <h3>Survey Selesai <i class="icon-check" style="color:green;font-size:50px;"></i></h3>
        <h4>Terimakasih atas partisipasi Anda dalam survey ini.</h4>
      </div>
    </div>
  </div>
</div> -->
<!-- modal -->
<style>
body{
  font-family:arial narrow, Georgia, Serif;
}
.srv{
  width: 125px;
}
#radioBtn .notActive{
    color: #3276b1;
    background-color: #fff;
}
.wizard {
    margin: 20px auto;
}

    .wizard .nav-tabs {
        position: relative;
        /*margin: 60px auto;*/
        margin-left: 370px;
        margin-bottom: 0;
        border-bottom-color: #e0e0e0;
    }

    .wizard > div.wizard-inner {
        position: relative;
    }

.connecting-line {
    height: 2px;
    background: #3d3d29;
    position: absolute;
    width: 30%;
    /*margin: 0 auto;*/
    left: 450px;
    right: 0;
    top: 50%;
    z-index: 1;
}

.wizard .nav-tabs > li.active > a, .wizard .nav-tabs > li.active > a:hover, .wizard .nav-tabs > li.active > a:focus {
    color: #555555;
    cursor: default;
    border: 0;
    border-bottom-color: transparent;
}

span.round-tab {
    width: 70px;
    height: 70px;
    line-height: 70px;
    display: inline-block;
    border-radius: 100px;
    background: #fff;
    border: 2px solid #e0e0e0;
    z-index: 2;
    position: absolute;
    left: 0;
    text-align: center;
    font-size: 25px;
}
span.round-tab i{
    color:#555555;
}
.wizard li.active span.round-tab {
    background: #fff;
    border: 2px solid #5bc0de;
    
}
.wizard li.active span.round-tab i{
    color: #5bc0de;
}

span.round-tab:hover {
    color: #333;
    border: 2px solid #333;
}

.wizard .nav-tabs > li {
    width: 15%;
}

.wizard li:after {
    content: " ";
    position: absolute;
    left: 46%;
    opacity: 0;
    margin: 0 auto;
    bottom: 0px;
    border: 5px solid transparent;
    border-bottom-color: #5bc0de;
    transition: 0.1s ease-in-out;
}

.wizard li.active:after {
    content: " ";
    position: absolute;
    left: 46%;
    opacity: 1;
    margin: 0 auto;
    bottom: 0px;
    border: 10px solid transparent;
    border-bottom-color: #5bc0de;
}

.wizard .nav-tabs > li a {
    width: 70px;
    height: 70px;
    margin: 20px auto;
    border-radius: 100%;
    padding: 0;
}

    .wizard .nav-tabs > li a:hover {
        background: transparent;
    }

.wizard .tab-pane {
    position: relative;
    padding-top: 50px;
}

.wizard h3 {
    margin-top: 0;
}

@media( max-width : 585px ) {

    .wizard {
        width: 90%;
        height: auto !important;
    }

    span.round-tab {
        font-size: 16px;
        width: 50px;
        height: 50px;
        line-height: 50px;
    }

    .wizard .nav-tabs > li a {
        width: 50px;
        height: 50px;
        line-height: 50px;
    }

    .wizard li.active:after {
        content: " ";
        position: absolute;
        left: 35%;
    }
}
</style>
<script>
function kondisiAwal(){
  document.getElementById('baik1').click();
  document.getElementById('baik2').click();
  document.getElementById('baik3').click();
  document.getElementById('baik4').click();
  document.getElementById('baik5').click();
  document.getElementById('baik6').click();
  document.getElementById('baik7').click();
  document.getElementById('baik8').click();
  document.getElementById('baik9').click();
  document.getElementById('baik10').click();
  document.getElementById('baik11').click();
  document.getElementById('baik12').click();
  document.getElementById('baik13').click();
  document.getElementById('baik14').click();
  document.getElementById('pdkn').value="SLTA";
//document.getElementById('umur').value=38;
document.getElementById('jkl').value="L";
document.getElementById('pkrjn').value="Wiraswasta";
  document.getElementById('sv1').value=3;
  document.getElementById('sv2').value=3;
  document.getElementById('sv3').value=3;
  document.getElementById('sv4').value=3;
  document.getElementById('sv5').value=3;
  document.getElementById('sv6').value=3;
  document.getElementById('sv7').value=3;
  document.getElementById('sv8').value=3;
  document.getElementById('sv9').value=3;
  document.getElementById('sv10').value=3;
  document.getElementById('sv11').value=3;
  document.getElementById('sv12').value=3;
  document.getElementById('sv13').value=3;
  document.getElementById('sv14').value=3;
}

kondisiAwal();


$('#radioBtn a').on('click', function(){
    var sel = $(this).data('title');
    var tog = $(this).data('toggle');
    $('#'+tog).prop('value', sel);
    
    $('a[data-toggle="'+tog+'"]').not('[data-title="'+sel+'"]').removeClass('active').addClass('notActive');
    $('a[data-toggle="'+tog+'"][data-title="'+sel+'"]').removeClass('notActive').addClass('active');
})
$(document).ready(function () {
    //Initialize tooltips
    $('.nav-tabs > li a[title]').tooltip();
    
    //Wizard
    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

        var $target = $(e.target);
    
        if ($target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".next-step").click(function (e) {

        var $active = $('.wizard .nav-tabs li.active');
        $active.next().removeClass('disabled');
        nextTab($active);

    });
    $(".prev-step").click(function (e) {

        var $active = $('.wizard .nav-tabs li.active');
        prevTab($active);

    });
});

function nextTab(elem) {
    $(elem).next().find('a[data-toggle="tab"]').click();
}
function prevTab(elem) {
    $(elem).prev().find('a[data-toggle="tab"]').click();
}

$(document).on('click', '#mdl', function(){
  $('.container').fadeOut('slow')
  function counter(time, url){
    var interval = setInterval(function(){
      $('#waktu').text(time);
      time = time - 1;
   
      if(time == 0){
        clearInterval(interval);
        window.location = url;
      }
    }, 1000);
  }

  counter(4, 'index.php');
})
// $(document).on('click', '#selesai', function(){
//   window.location='index.php';
//   // window.location='index.php';
// })
</script>