<div class="container" style='text-align: center; vertical-align: middle;'>
	<img src="img/ico.png" alt="">
</div>