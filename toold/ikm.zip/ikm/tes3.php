<script src="plugin/bootstrap/js/chart-master/Chart.js"></script>
<script src="plugin/bootstrap/js/chart-master/legend.js"></script>
<script>
if(!!(window.addEventListener)) window.addEventListener('DOMContentLoaded', main);
else window.attachEvent('onload', main);


function main() {

}
</script>
<head>
		
		<meta name = "viewport" content = "initial-scale = 1, user-scalable = no">
		<style>
			canvas{
			}
		</style>
	</head>
	<body>
<?PHP  
include_once'plugin.php';

/* include'config/database.php';
include'objects/survey.php';
  
// instantiate database class
$database = new Database();
$db = $database->getConnection();
  
// initialize object
$survey = new Survey($db); */



$x=$survey->getpkn();
$decode = json_decode($x, true);

/* foreach($decode['data'] as $row){
	echo $row['l'];echo $row['p']."<br>";
} */
		  
					  
?>
	
	
 	

<div class="col-lg-5"> <br>
		<canvas id="pieChart3" height="200" width="200"></canvas>
		<div id="pieLegend3"></div>	
</div>		
<?PHP
echo ' <div class="col-lg-5"><br>';
foreach($decode['data'] as $row){
	echo " <i class=''>PNS/TNI/POLRI : ".number_format($row['a1'],2)."% </i></br>";
	echo "<i class=''>Pegawai Swasta : ".number_format($row['a2'],2)."% </i></br>";
	echo "<i class=''>Wiraswasta : ".number_format($row['a3'],2)."% </i></br>";
	echo " <i class=''>Pelajar/Mhs : ".number_format($row['a4'],2)."% </i></br>";
	echo "<i class=''>Lainnya : ".number_format($row['a5'],2)."% </i></br>";
	
}
?>
</div>

	<script>
		var pieData = [
		        	
				{
					value: <?PHP echo number_format($row['a1'],2);?>,
					color:"#F38630",
					label:"PNS/TNI/POLRI"
				},
				{
					value : <?PHP echo number_format($row['a2'],2);?>,
					color : "#69D2E7",
					label :"Pegawai Swasta"
				} ,
				{
					value : <?PHP echo number_format($row['a3'],2);?>,
					color : "#69D2a3",
					label :"Wiraswasta"
				} ,
				{
					value: <?PHP echo number_format($row['a4'],2);?>,
					color:"#4a864a",
					label:"Pelajar/Mhs"
				},
				{
					value : <?PHP echo number_format($row['a5'],2);?>,
					color : "#5aD25a",
					label :"Lainnya"
				}  
			
			];

	var myPie = new Chart(document.getElementById("pieChart3").getContext("2d")).Pie(pieData);
	
	

	//var myPie = new Chart(document.getElementById("pieChart").getContext("2d")).Pie(pieData);
    //var pieChart = Chart(myPie).Pie(data);

    legend(document.getElementById("pieLegend3"), data, myPie);
	</script>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</body>