<link rel="stylesheet" href="plugin/bootstrap/css/bootstrap.css">
<link href="plugin/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<?php
// include database and object files
include'config/database.php';
include'objects/survey.php';
  
// instantiate database class
$database = new Database();
$db = $database->getConnection();
  
// initialize object
$survey = new Survey($db);
  
        
// create product
$x=$survey->getr(); 
$decode =json_decode($x,true);
foreach($decode['data'] as $row){
$r=$row['responden'].' orang';
}

$x=$survey->gethasil();  
$data =json_decode($x,true);
//echo "<p>Nilai IKM ".number_format($data['nilaiikm'],4)."</p>";
//echo "<p>Kinerja Unit ".$data['kinerjaunit']."</p>";
$ik=number_format(($data['nilaiikm']/25),4);

$x=$survey->gethasilnrr();
$decode = json_decode($x, true);
?>
<nav role="navigation" class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">Laporan Hasil Survey</a>
        </div>
        <!-- Collection of nav links and other content for toggling -->
        <div id="navbarCollapse" class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="login.php">Keluar</a></li>
            </ul>
        </div>
    </div>
</nav>
<br>
<br>
<?php
echo'<div class="row">
<div class="col-lg-3"></div>';
echo'<div class="col-lg-6">
	<section class="panel">
    <h3><header class="panel-heading">Indeks Kepuasan Masyarakat</header></h3>';
echo "<table class='table table-bordered table-striped table-advance table-hover'>";
echo "<thead><tr><th class=''>Kode Unsur</th>";
echo "<th>Unsur</th>";
echo "<th>NRR</th>";
echo "<th>NRR x 1/14</th></tr></thead><tbody class=''>";
foreach($decode['data'] as $row){
    echo "<tr>";    
		echo "<td id='kd_unsur'>".$row['kd_unsur'] ."</td>";
        echo "<td id='unsur'>".$row['unsur'] ."</td>";
        echo "<td id='nrr'>".number_format($row['nrr'],4) ."</td>";
        echo "<td id='nrtt'>".number_format($row['nrrt'],4) ."</td>";
    echo "<tr>";   
}
 echo "</tbody>";
 
 echo"<tfoot><th></th><th><em>Responden : ".$r."</em></th><th><em>Total NRRT </em></th><th><em>".$ik."</em></th></tfoot>
 
 </table>";

 
echo'</section></div></div>';

echo'<div class="row">
<div class="col-lg-3"></div>';
echo'<div class="col-lg-6">
<div class="panel-body">
                              <div class="alert alert-success alert-block fade in">
                                  <button data-dismiss="alert" class="close close-sm" type="button">
                                      <i class="icon-remove"></i>
                                  </button>
								  <b>Kategori kinerja</b><hr>
                                  <h3>
                                      <i class="icon-ok-sign"></i>
                                      '.$data['kinerjaunit'].'
                                  </h3>
                                  <h4><p><em>Nilai IKM :'.$ik.' x 25 = '.number_format($ik*25,4).'</em></p></h4>
								  
                             
                              </div></div>
                             </div> </div>';









$x=$survey->getlp();
$data =json_decode($x,true);
//echo "<p>Laki laki ".number_format($data['l'],2)."</p>";
//echo "<p>Perempuan ".number_format($data['p'],2)."</p>";




echo'<div class="row">
<div class="col-lg-3"></div>';
echo'<div class="col-lg-6">
	<section class="panel">
    <header class="panel-heading">Indeks Kepuasan Masyarakat</header>';
include_once'tes5.php';
echo'</section></div></div>';

echo'<div class="row">
<div class="col-lg-1"></div>';
echo'<div class="col-lg-5">
	<section class="panel">
    <header class="panel-heading">Jenis Kelamin Responden</header>';
include_once'tes.php';
echo'</section></div>';

echo'<div class="col-lg-5">
	<section class="panel">
    <header class="panel-heading">Tingkat Pendidikan Responden</header>';
include_once'tes2.php';
echo'</section></div></div>';
echo'<div class="row">
<div class="col-lg-1"></div><div class="col-lg-5"><hr></div><div class="col-lg-5"><hr></div></div>';

echo'<div class="row">
<div class="col-lg-1"></div>';
echo'<div class="col-lg-5">
	<section class="panel">
    <header class="panel-heading">Profesi Responden</header>';
include_once'tes3.php';
echo'</section></div>';
echo'<div class="col-lg-5">
	<section class="panel">
    <header class="panel-heading">Usia Responden</header>';
include_once'tes4.php';
echo'</section></div></div>';
					  
echo'<div class="row">
<div class="col-lg-1"></div><div class="col-lg-5"><hr></div><div class="col-lg-5"><hr></div></div>';

?>