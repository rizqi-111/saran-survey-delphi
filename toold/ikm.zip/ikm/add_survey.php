<?php
// include database and object files
include'config/database.php';
include'objects/survey.php';
  
// instantiate database class
$database = new Database();
$db = $database->getConnection();
  
// initialize object
$survey = new Survey($db);
  
// set values
$survey->umur=$_POST['umur'];
$survey->jkl=$_POST['jkl'];
$survey->pdkn=$_POST['pdkn'];
$survey->pkrjn=$_POST['pkrjn'];
$survey->sv1=$_POST['sv1'];
$survey->sv2=$_POST['sv2'];
$survey->sv3=$_POST['sv3'];
$survey->sv4=$_POST['sv4'];
$survey->sv5=$_POST['sv5'];
$survey->sv6=$_POST['sv6'];
$survey->sv7=$_POST['sv7'];
$survey->sv8=$_POST['sv8'];
$survey->sv9=$_POST['sv9'];
$survey->sv10=$_POST['sv10'];
$survey->sv11=$_POST['sv11'];
$survey->sv12=$_POST['sv12'];
$survey->sv13=$_POST['sv13'];
$survey->sv14=$_POST['sv14'];
$survey->tgl=date("Y-m-d",time());
// set your default timezone

        
// create product
$survey->tambah();

?>