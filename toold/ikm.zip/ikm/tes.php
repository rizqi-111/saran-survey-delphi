<script src="plugin/bootstrap/js/chart-master/Chart.js"></script>
<script src="plugin/bootstrap/js/chart-master/legend.js"></script>
  <link href="plugin/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="plugin/bootstrap/css/bootstrap-reset.css" rel="stylesheet">
    <!--external css-->
    <link href="plugin/bootstrap/css/font-awesome.css" rel="stylesheet" />
    <!-- Custom styles for this template -->
    <link href="plugin/bootstrap/css/style.css" rel="stylesheet">
    <link href="plugin/bootstrap/css/style-responsive.css" rel="stylesheet" />
<script>
if(!!(window.addEventListener)) window.addEventListener('DOMContentLoaded', main);
else window.attachEvent('onload', main);


function main() {

}
</script>

	<body>
<?PHP  
include_once'plugin.php';

/* include'config/database.php';
include'objects/survey.php';
  
// instantiate database class
$database = new Database();
$db = $database->getConnection();
  
// initialize object
$survey = new Survey($db);
 */


$x=$survey->getlp2();
$decode = json_decode($x, true);
/* foreach($decode['data'] as $row){
	echo $row['l'];echo $row['p']."<br>";
} */

					  
					  
?>
	
                       

<div class="col-lg-5"> <br>
		<canvas id="pieChart" height="200" width="200"></canvas>
		<div id="pieLegend"></div>	
</div>
<?PHP
echo ' <div class="col-lg-4"><br>';
 
foreach($decode['data'] as $row){
	echo " <i class=''>Laki - laki : ".number_format($row['l'],2)."% </i></br>";
	echo "<i class=''>Perempuan : ".number_format($row['p'],2)."% </i>";
}

?>
</div>

                      
	<script>
		var pieData = [
		        	
				{
					value: <?PHP echo number_format($row['l'],2);?>,
					color:"#F38630",
					label:"Laki - laki"
				},
				{
					value : <?PHP echo number_format($row['p'],2);?>,
					color : "#69D2E7",
					label :"Perempuan"
				}/* ,
				{
					value : 100,
					color : "#69D2E7"
				} */
			
			];

	var myPie = new Chart(document.getElementById("pieChart").getContext("2d")).Pie(pieData);
	
	

	//var myPie = new Chart(document.getElementById("pieChart").getContext("2d")).Pie(pieData);
    //var pieChart = Chart(myPie).Pie(data);

    legend(document.getElementById("pieLegend"), data, myPie);
	</script>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	</body>