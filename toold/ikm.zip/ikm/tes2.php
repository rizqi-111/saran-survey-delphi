<script src="plugin/bootstrap/js/chart-master/Chart.js"></script>
<script src="plugin/bootstrap/js/chart-master/legend.js"></script>
<script>
if(!!(window.addEventListener)) window.addEventListener('DOMContentLoaded', main);
else window.attachEvent('onload', main);


function main() {

}
</script>
<head>
		
		<meta name = "viewport" content = "initial-scale = 1, user-scalable = no">
		<style>
			canvas{
			}
		</style>
	</head>
	<body>
<?PHP  
include_once'plugin.php';
$x=$survey->getpdd();
$decode = json_decode($x, true);

/* foreach($decode['data'] as $row){
	echo $row['l'];echo $row['p']."<br>";
} */
			  
					  
?>
	
 
<div class="col-lg-5"><br>	
		<canvas id="pieChart2" height="200" width="200"></canvas>
		<div id="pieLegend2"></div>
</div>		
<?PHP
echo ' <div class="col-lg-5"><br>';
foreach($decode['data'] as $row){
	echo " <i class=''>SD kebawah : ".number_format($row['a1'],2)."% </i></br>";
	echo "<i class=''>SMP : ".number_format($row['a2'],2)."% </i></br>";
	echo "<i class=''>SLTA : ".number_format($row['a3'],2)."% </i></br>";
	echo " <i class=''>D1-D2-D3-D4 : ".number_format($row['a4'],2)."% </i></br>";
	echo "<i class=''>S1 : ".number_format($row['a5'],2)."% </i></br>";
	echo "<i class=''>S2 keatas : ".number_format($row['a6'],2)."% </i></br>";
}

?>
</div>


	<script>
		var pieData = [
		        	
				{
					value: <?PHP echo number_format($row['a1'],2);?>,
					color:"#F38630",
					label:"SD kebawah"
				},
				{
					value : <?PHP echo number_format($row['a2'],2);?>,
					color : "#69D2E7",
					label :"SMP"
				} ,
				{
					value : <?PHP echo number_format($row['a3'],2);?>,
					color : "#69D2a3",
					label :"SLTA"
				} ,
				{
					value: <?PHP echo number_format($row['a4'],2);?>,
					color:"#4a864a",
					label:"D1-D2-D3-D4"
				},
				{
					value : <?PHP echo number_format($row['a5'],2);?>,
					color : "#5aD25a",
					label :"S1"
				} ,
				{
					value : <?PHP echo number_format($row['a6'],2);?>,
					color : "#19D2a6",
					label :"S2 Keatas"
				} 
			
			];

	var myPie = new Chart(document.getElementById("pieChart2").getContext("2d")).Pie(pieData);
	
	

	//var myPie = new Chart(document.getElementById("pieChart").getContext("2d")).Pie(pieData);
    //var pieChart = Chart(myPie).Pie(data);

    legend(document.getElementById("pieLegend2"), data, myPie);
	</script>
	
	
	</body>