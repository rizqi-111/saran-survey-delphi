<?php
class Survey{
	private $conn;
	private $table_name="tb_ikm";

	public $umur;
	public $jkl;
	public $pdkn;
	public $pkrjn;
	public $sv1;
	public $sv2;
	public $sv3;
	public $sv4;
	public $sv5;	
	public $sv6;
	public $sv7;
	public $sv8;
	public $sv9;
	public $sv10;
	public $sv11;
	public $sv12;
	public $sv13;
	public $sv14;
	public $r;
	public $data;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function tambah(){
		$query="INSERT INTO
				" .$this->table_name. " 
			   SET 
				umur=:umur, jkl=:jkl, pdkn=:pdkn, pkrjn=:pkrjn, sv1=:sv1, sv2=:sv2, sv3=:sv3, sv4=:sv4, sv5=:sv5, sv6=:sv6, sv7=:sv7, sv8=:sv8, sv9=:sv9, sv10=:sv10, sv11=:sv11, sv12=:sv12, sv13=:sv13, sv14=:sv14, tgl=:tgl";

		$stmt=$this->conn->prepare($query);

		$stmt->bindParam(":umur", $this->umur);
		$stmt->bindParam(":jkl", $this->jkl);
		$stmt->bindParam(":pdkn", $this->pdkn);
		$stmt->bindParam(":pkrjn", $this->pkrjn);
		$stmt->bindParam(":sv1", $this->sv1);
		$stmt->bindParam(":sv2", $this->sv2);
		$stmt->bindParam(":sv3", $this->sv3);
		$stmt->bindParam(":sv4", $this->sv4);
		$stmt->bindParam(":sv5", $this->sv5);
		$stmt->bindParam(":sv6", $this->sv6);
		$stmt->bindParam(":sv7", $this->sv7);
		$stmt->bindParam(":sv8", $this->sv8);
		$stmt->bindParam(":sv9", $this->sv9);
		$stmt->bindParam(":sv10", $this->sv10);
		$stmt->bindParam(":sv11", $this->sv11);
		$stmt->bindParam(":sv12", $this->sv12);
		$stmt->bindParam(":sv13", $this->sv13);
		$stmt->bindParam(":sv14", $this->sv14);
		$stmt->bindParam(":tgl", $this->tgl);
		if ($stmt->execute()) {
			return true;
		}else{
			return false;
		}
	}
	
	
	public function gethasil(){		
		$query='select nilaiikm,
				case when nilaiikm>81.25 then "Sangat Baik"  
					 when nilaiikm<81.26 and nilaiikm>62.50 then "Baik" 
					 when nilaiikm<62.51 and nilaiikm>43.75 then "Kurang Baik" 
					 when nilaiikm<43.76 and nilaiikm>24.99 then "Tidak Baik" 
				end 
				as kinerjaunit 
				from (select a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12+a13+a14 as nilaiindeks,(a1+a2+a3+a4+a5+a6+a7+a8+a9+a10+a11+a12+a13+a14)*25 as nilaiikm from v_avg) as y
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		$hasil=json_encode($stmt->fetch());
		//var_dump($hasil);
		return ($hasil);
	}
	
	public function gethasilnrr(){		
		$query='SELECT kd_unsur,unsur,u1 as nrr, a1 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u1"
				union
				SELECT kd_unsur,unsur,u2 as nrr, a2 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u2"
				union
				SELECT kd_unsur,unsur,u3 as nrr, a3 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u3"
				union
				SELECT kd_unsur,unsur,u4 as nrr, a4 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u4"
				union
				SELECT kd_unsur,unsur,u5 as nrr, a5 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u5"
				union
				SELECT kd_unsur,unsur,u6 as nrr, a6 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u6"
				union
				SELECT kd_unsur,unsur,u7 as nrr, a7 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u7"
				union
				SELECT kd_unsur,unsur,u8 as nrr, a8 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u8"
				union
				SELECT kd_unsur,unsur,u9 as nrr, a9 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u9"
				union
				SELECT kd_unsur,unsur,u10 as nrr, a10 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u10"
				union
				SELECT kd_unsur,unsur,u11 as nrr, a11 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u11"
				union
				SELECT kd_unsur,unsur,u12 as nrr, a12 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u12"
				union
				SELECT kd_unsur,unsur,u13 as nrr, a13 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u13"
				union
				SELECT kd_unsur,unsur,u14 as nrr, a14 as nrrt FROM `v_avg` join tb_unsur on tb_unsur.kd_unsur="u14"
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		$i=0;
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
	
	
	public function getlp(){		
		$query='SELECT 
				laki/(laki+perempuan)*100 as l,
				perempuan/(laki+perempuan)*100 as p from(
				SELECT 
				SUM(IF(jkl="L",1,0)) AS laki, 
				SUM(IF(jkl="P",1,0)) AS perempuan 
				FROM tb_ikm) as x';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		$hasil=json_encode($stmt->fetch());
		//var_dump($hasil);
		return ($hasil);
		
		/* $hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x); */
	}
	
	
	public function getlp2(){		
		$query='SELECT 
				laki/(laki+perempuan)*100 as l,
				perempuan/(laki+perempuan)*100 as p from(
				SELECT 
				SUM(IF(jkl="L",1,0)) AS laki, 
				SUM(IF(jkl="P",1,0)) AS perempuan 
				FROM tb_ikm) as x';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		
		
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
	
	public function getpdd(){		
		$query='
			select a/(a+b+c+d+e+f)*100 as a1,
			b/(a+b+c+d+e+f)*100 as a2,
			c/(a+b+c+d+e+f)*100 as a3,
			d/(a+b+c+d+e+f)*100 as a4,
			e/(a+b+c+d+e+f)*100 as a5,
			f/(a+b+c+d+e+f)*100 as a6 from (SELECT 
				SUM(IF(pdkn="SD ke bawah",1,0)) AS a, 
				SUM(IF(pdkn="SLTP",1,0)) AS b,
				SUM(IF(pdkn="SLTA",1,0)) AS c,
				SUM(IF(pdkn="D1-D2--D4",1,0)) AS d,
				SUM(IF(pdkn="S1",1,0)) AS e,
				SUM(IF(pdkn="S2 ke atas",1,0)) AS f
				FROM tb_ikm ) as y
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		
		
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
	
	public function getpkn(){		
		$query='
			select a/(a+b+c+d+e)*100 as a1,
			b/(a+b+c+d+e)*100 as a2,
			c/(a+b+c+d+e)*100 as a3,
			d/(a+b+c+d+e)*100 as a4,
			e/(a+b+c+d+e)*100 as a5 from (SELECT 
				SUM(IF(pkrjn="PNS/TNI/POLRI",1,0)) AS a, 
				SUM(IF(pkrjn="Pegawai Swasta",1,0)) AS b,
				SUM(IF(pkrjn="Wiraswasta",1,0)) AS c,
				SUM(IF(pkrjn="Pelajar/Mahasiswa",1,0)) AS d,
				SUM(IF(pkrjn="Lainnya",1,0)) AS e
				FROM tb_ikm ) as y
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		
		
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
		public function getumur(){		
		$query='
			select a/(a+b+c+d+e)*100 as a1,
			b/(a+b+c+d+e)*100 as a2,
			c/(a+b+c+d+e)*100 as a3,
			d/(a+b+c+d+e)*100 as a4,
			e/(a+b+c+d+e)*100 as a5 from (SELECT 
				SUM(IF(umur<26 and umur>15,1,0)) AS a, 
				SUM(IF(umur<41 and umur>25,1,0)) AS b,
				SUM(IF(umur<61 and umur>40,1,0)) AS c,
				SUM(IF(umur>60,1,0)) AS d,
				SUM(IF(umur=0,1,0)) AS e
				FROM tb_ikm ) as y
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		
		
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
		public function getr(){		
		$query='
			select count(id) as responden FROM tb_ikm 
				';	
		$stmt=$this->conn->prepare($query);
		$stmt->execute();
		
		
		$hasil=($stmt->fetchAll());
		$x= json_encode(array('data'=>$hasil));
		return ($x);
	}
	
}



