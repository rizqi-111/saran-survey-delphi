<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Survey Kepuasan Masyarakat</title>
</head>
<?php  
	include_once'plugin.php';
?>
<style>
body{
	background-image: url('img/bg.jpg');
}
.blink_me{
	font-family:Arial, Georgia, Serif;
}
#open-survey{
	margin-left: 220px;
	margin-top: -100px;
}
#admn{
	margin-left: 220px;
	margin-top: -100px;
}
#page-content{
	margin-top: 0px;
}
</style>
<body class="">
	<div id='page-content'>
		
	</div>
	<div class="container">
		<div class="row">
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<button type="button" id='open-survey' class="btn btn-primary btn-lg"><i class="icon-play"></i>Mulai Survey</button>
			</div>
			<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
				<button type="button" id="admn" class="btn btn-danger btn-lg">Admin</button>
			</div>
		</div>
	</div>
<a class="btn btn-primary" data-toggle="modal" href='#modal-id' id="sembunyi">Trigger modal</a>
<!-- modal -->
<div class="modal fade" id="modal-id" data-keyboard="false" data-backdrop="static" style='margin-top: 0px;background-image: url("img/bg.jpg");'>
<div class="row">
<div class="col-lg-3"></div>
<div class="col-lg-6">
<div class="panel-body">
  <div class="alert alert-success alert-block fade in" style='margin-top: 250px;'>
  <button data-dismiss="modal" class="close close-sm" id="btn-close" type="button">
  <i class="icon-close"></i>
  </button>
  <h4 style=''>
  <i class="icon-check"></i>
  Success!
  </h4>
  <p><strong>Terimakasih</strong> atas partisipasi Anda dalam survey ini...</p>
 </div>	 </div> </div>
	
	
	
	
	
</div></div>
<!-- modal -->
<script>
$(document).ready(function(){
document.getElementById('sembunyi').style.visibility = 'hidden';
function blinker() {
    $('.blink_me').fadeOut(500);
    $('.blink_me').fadeIn(500);
}
setInterval(blinker, 1000);

tampilForm();
function tampilForm(){
	$('#page-content').fadeIn('slow', function(){
	        $('#page-content').load('components/icon.php', function(){
	            // fade in effect
	            $('#page-content').fadeIn('slow');
	        });
	});
}

$('#open-survey').click(function(){
	$('#open-survey').hide();
    $('#page-content').fadeOut('slow', function(){
            $('#page-content').load('components/form_survey.php', function(){ 
            $('#page-content').fadeIn('slow');
            $('#admn').hide();
        });
    });
});

$(document).on('submit', '#insert-survey', function() {
    $.post("add_survey.php", $(this).serialize())
        .done(function(data) {
        	document.getElementById('sembunyi').click();
        	$('#open-survey').fadeIn();
            tampilForm();
            $('#admn').show();
            setInterval(function(){ 
			    document.getElementById("btn-close").click();
			}, 4000);
        });         
    return false;
});    

$('#admn').click(function(){
	window.location='login.php';
});

});

</script>
</body>
</html>