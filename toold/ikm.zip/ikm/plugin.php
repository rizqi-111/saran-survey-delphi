  <link rel="stylesheet" href="plugin/bootstrap/css/bootstheme.min.css">
  <link rel="stylesheet" href="plugin/bootstrap/css/svy.css">
  <link rel="stylesheet" href="plugin/bootstrap/css/font-awesome.min.css">
  <link rel="stylesheet" href="plugin/bootstrap/css/font-awesome.css">
 
<script src="plugin/bootstrap/js/jquery-2.2.3.min.js"></script>
<script src="plugin/bootstrap/js/bootstrap.min.js"></script>
<!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script> -->