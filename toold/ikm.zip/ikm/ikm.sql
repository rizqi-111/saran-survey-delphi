-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 29 Agu 2016 pada 04.17
-- Versi Server: 10.1.10-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ikm`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `text` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `article`
--

INSERT INTO `article` (`id`, `text`) VALUES
(1, 'Prosedur pelayanan'),
(2, 'Persyaratan pelayanan'),
(3, 'Kejelasan petugas pelayanan'),
(4, 'Kedisiplinan petugas pelayanan'),
(5, 'Tanggung jawab petugas pelayanan'),
(6, 'Kemampuan petugas pelayanan'),
(7, 'Kecepatan pelayanan'),
(8, 'Keadilan mendapatkan pelayanan'),
(9, 'Kesopanan dan keramahan petugas'),
(10, 'Kewajaran biaya pelayanan'),
(11, 'Kepastian biaya pelayanan'),
(12, 'Kepastian jadwal pelayanan'),
(13, 'Kenyamanan lingkungan'),
(14, 'Keamanan pelayanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `article_rating`
--

CREATE TABLE `article_rating` (
  `article_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `idu` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `article_rating`
--

INSERT INTO `article_rating` (`article_id`, `rating`, `idu`) VALUES
(9, 5, 0),
(1, 5, 0),
(2, 5, 0),
(3, 3, 0),
(6, 3, 0),
(11, 2, 0),
(14, 5, 0),
(13, 4, 0),
(12, 3, 0),
(10, 3, 0),
(8, 3, 0),
(7, 3, 0),
(5, 3, 0),
(4, 5, 0),
(10, 5, 0),
(11, 4, 0),
(11, 5, 0),
(3, 5, 0),
(5, 5, 0),
(2, 2, 0),
(3, 5, 0),
(2, 5, 0),
(6, 5, 0),
(2, 5, 0),
(5, 5, 0),
(6, 5, 0),
(7, 5, 0),
(8, 5, 0),
(8, 5, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(150) NOT NULL,
  `rating` float NOT NULL,
  `total_rating` float NOT NULL,
  `total_rates` int(11) NOT NULL,
  `ip_address` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `items`
--

INSERT INTO `items` (`id`, `title`, `description`, `image`, `rating`, `total_rating`, `total_rates`, `ip_address`) VALUES
(1, 'Typography Visual Inspirations', 'Typography is the art and technique of arranging type in order to make language visible. The arrangement of type involves the selection of typefaces, point size, line length, leading (line spacing), adjusting the spaces between groups of letters (tracking) and adjusting the space between pairs of letters (kerning).', '', 3.69, 36.9, 10, ',127.0.0.1,127.0.0.1,127.0.0.1,127.0.0.1,,,,,,'),
(2, 'Pratical Guide To Your First Wordpress Plugin :- Part 1 ', 'Starting out as a simple Content Management System wordpress has turned into a fully featured solution for companies, individuals and web masters. Not only wordpress provides a GUI to manage post or add new themes. It also ', '', 3.725, 29.8, 8, ',127.0.0.1,,,,,,,'),
(3, 'Typography Visual Inspirations', 'Typography is the art and technique of arranging type in order to make language visible. The arrangement of type involves the selection of typefaces, point size, line length, leading (line spacing), adjusting the spaces between groups of letters .', '', 4.11111, 37, 9, ',127.0.0.1,127.0.0.1,127.0.0.1,127.0.0.1,,,,,'),
(4, 'Pratical Guide To Your First Wordpress Plugin :- Part 1 ', 'Starting out as a simple Content Management System wordpress has turned into a fully featured solution for companies, individuals and web masters. Not only wordpress provides a GUI to manage post or add new themes. It also provides easy to use functions to write custom code to enhance the functionality or design of wordpress ', '', 4.55, 27.3, 6, ',127.0.0.1,,,,,');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rating`
--

CREATE TABLE `rating` (
  `id` int(11) NOT NULL,
  `php` int(11) NOT NULL,
  `asp` int(11) NOT NULL,
  `jsp` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `rating`
--

INSERT INTO `rating` (`id`, `php`, `asp`, `jsp`) VALUES
(5, 0, 0, 0),
(6, 0, 0, 0),
(7, 0, 0, 0),
(8, 0, 0, 0),
(9, 0, 0, 0),
(10, 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_ikm`
--

CREATE TABLE `tb_ikm` (
  `id` int(9) NOT NULL,
  `umur` int(3) DEFAULT NULL,
  `jkl` varchar(1) DEFAULT NULL,
  `pdkn` varchar(15) DEFAULT NULL,
  `pkrjn` varchar(20) DEFAULT NULL,
  `sv1` int(11) DEFAULT '3',
  `sv2` int(11) DEFAULT '3',
  `sv3` int(11) DEFAULT '3',
  `sv4` int(11) DEFAULT '3',
  `sv5` int(11) DEFAULT '3',
  `sv6` int(11) DEFAULT '3',
  `sv7` int(11) DEFAULT '3',
  `sv8` int(11) DEFAULT '3',
  `sv9` int(11) DEFAULT '3',
  `sv10` int(11) DEFAULT '3',
  `sv11` int(11) DEFAULT '3',
  `sv12` int(11) DEFAULT '3',
  `sv13` int(11) DEFAULT '3',
  `sv14` int(11) DEFAULT '3',
  `tgl` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_ikm`
--

INSERT INTO `tb_ikm` (`id`, `umur`, `jkl`, `pdkn`, `pkrjn`, `sv1`, `sv2`, `sv3`, `sv4`, `sv5`, `sv6`, `sv7`, `sv8`, `sv9`, `sv10`, `sv11`, `sv12`, `sv13`, `sv14`, `tgl`) VALUES
(1, 0, 'L', 'SLTA', 'Wiraswasta', 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, '2016-08-29'),
(2, 878, 'P', 'SLTA', 'Lainnya', 2, 4, 3, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3, 3, '2016-08-29');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_unsur`
--

CREATE TABLE `tb_unsur` (
  `id` int(11) NOT NULL,
  `unsur` varchar(200) NOT NULL,
  `kd_unsur` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_unsur`
--

INSERT INTO `tb_unsur` (`id`, `unsur`, `kd_unsur`) VALUES
(1, 'Prosedur pelayanan', 'u1'),
(2, 'Persyaratan pelayanan', 'u2'),
(3, 'Kejelasan petugas pelayanan', 'u3'),
(4, 'Kedisiplinan petugas pelayanan', 'u4'),
(5, 'Tanggung jawab petugas pelayanan', 'u5'),
(6, 'Kemampuan petugas pelayanan', 'u6'),
(7, 'Kecepatan pelayanan', 'u7'),
(8, 'Keadilan mendapatkan pelayanan', 'u8'),
(9, 'Kesopanan dan keramahan petugas', 'u9'),
(10, 'Kewajaran biaya pelayanan', 'u10'),
(11, 'Kepastian biaya pelayanan', 'u11'),
(12, 'Kepastian jadwal pelayanan', 'u12'),
(13, 'Kenyamanan lingkungan', 'u13'),
(14, 'Keamanan pelayanan', 'u14');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_avg`
--
CREATE TABLE `v_avg` (
`u1` decimal(14,4)
,`a1` decimal(19,8)
,`u2` decimal(14,4)
,`a2` decimal(19,8)
,`u3` decimal(14,4)
,`a3` decimal(19,8)
,`u4` decimal(14,4)
,`a4` decimal(19,8)
,`u5` decimal(14,4)
,`a5` decimal(19,8)
,`u6` decimal(14,4)
,`a6` decimal(19,8)
,`u7` decimal(14,4)
,`a7` decimal(19,8)
,`u8` decimal(14,4)
,`a8` decimal(19,8)
,`u9` decimal(14,4)
,`a9` decimal(19,8)
,`u10` decimal(14,4)
,`a10` decimal(19,8)
,`u11` decimal(14,4)
,`a11` decimal(19,8)
,`u12` decimal(14,4)
,`a12` decimal(19,8)
,`u13` decimal(14,4)
,`a13` decimal(19,8)
,`u14` decimal(14,4)
,`a14` decimal(19,8)
);

-- --------------------------------------------------------

--
-- Struktur dari tabel `wcd_rate`
--

CREATE TABLE `wcd_rate` (
  `id` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `rate` int(11) NOT NULL,
  `dt_rated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `wcd_rate`
--

INSERT INTO `wcd_rate` (`id`, `id_post`, `ip`, `rate`, `dt_rated`) VALUES
(1, 1, '::1', 5, '2016-08-11 07:34:32');

-- --------------------------------------------------------

--
-- Struktur untuk view `v_avg`
--
DROP TABLE IF EXISTS `v_avg`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_avg`  AS  select avg(`tb_ikm`.`sv1`) AS `u1`,((avg(`tb_ikm`.`sv1`) * 1) / 14) AS `a1`,avg(`tb_ikm`.`sv2`) AS `u2`,((avg(`tb_ikm`.`sv2`) * 1) / 14) AS `a2`,avg(`tb_ikm`.`sv3`) AS `u3`,((avg(`tb_ikm`.`sv3`) * 1) / 14) AS `a3`,avg(`tb_ikm`.`sv4`) AS `u4`,((avg(`tb_ikm`.`sv4`) * 1) / 14) AS `a4`,avg(`tb_ikm`.`sv5`) AS `u5`,((avg(`tb_ikm`.`sv5`) * 1) / 14) AS `a5`,avg(`tb_ikm`.`sv6`) AS `u6`,((avg(`tb_ikm`.`sv6`) * 1) / 14) AS `a6`,avg(`tb_ikm`.`sv7`) AS `u7`,((avg(`tb_ikm`.`sv7`) * 1) / 14) AS `a7`,avg(`tb_ikm`.`sv8`) AS `u8`,((avg(`tb_ikm`.`sv8`) * 1) / 14) AS `a8`,avg(`tb_ikm`.`sv9`) AS `u9`,((avg(`tb_ikm`.`sv9`) * 1) / 14) AS `a9`,avg(`tb_ikm`.`sv10`) AS `u10`,((avg(`tb_ikm`.`sv10`) * 1) / 14) AS `a10`,avg(`tb_ikm`.`sv11`) AS `u11`,((avg(`tb_ikm`.`sv11`) * 1) / 14) AS `a11`,avg(`tb_ikm`.`sv12`) AS `u12`,((avg(`tb_ikm`.`sv12`) * 1) / 14) AS `a12`,avg(`tb_ikm`.`sv13`) AS `u13`,((avg(`tb_ikm`.`sv13`) * 1) / 14) AS `a13`,avg(`tb_ikm`.`sv14`) AS `u14`,((avg(`tb_ikm`.`sv14`) * 1) / 14) AS `a14` from `tb_ikm` where 1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_ikm`
--
ALTER TABLE `tb_ikm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_unsur`
--
ALTER TABLE `tb_unsur`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wcd_rate`
--
ALTER TABLE `wcd_rate`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tb_ikm`
--
ALTER TABLE `tb_ikm`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tb_unsur`
--
ALTER TABLE `tb_unsur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `wcd_rate`
--
ALTER TABLE `wcd_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
