==================================================
        ARWordReport Delphi component. Freeware.

	Author        : Anton Ryazanov
	Version       : 2.3
	Copyright     : Anton Ryazanov

	Description   : TARWordReport component
==================================================

	ARWordReport - is easy-to-use reports generation component. With ARWordReport you can use Microsoft� Word to print, view and edit reports, generated from your application. With ARWordReport You can implement a very flexible report solution, which
gives end-users a way to create wide range of own reports according to they needs easy. It`s also very simple to include ARWordReport in your projects. There are only few lines of code needed to generate an report!

	MS Word 97/2000/XP/2003/2007/2010/2013 compatible.

	See also: ARExcelReport 
		 (http://www.vector-ski.com/reports).


 	Benefits
              * End users got interactive reports in well-known Microsoft� Word environment.
              * Extremely simple report templates creation direct in Microsoft� Word using its full formatting abilities.
              * No Microsoft� Word addons and tweaks needed.
              * Compatible with any Microsoft� Word versions begining from Word 97.

	Highlights.

              * Database-independent.
              * Simple report templates creation direct in MS Word using its full formatting abilities.
              * Passing data into report by different ways including named text parameters, datasets and OnTag event.
              * Data tables in report.
              * Conditional blocks in report template.
              * Custom SQL Queries in report template.
              * Custom macros in report.

	Compatibility : MS Word 97(SP2?),2000/XP/2003/2007/2010/2013.
	Environment   : Delphi 3,4,5,6,7,2005,2006,2007,2009,2010,XE,XE2..XE8,10,10.1, C++Builder.
	E-Mail        : vsoft@vector-ski.ru
	WebSite       : http://www.vector-ski.com/reports

=========================================================
Installation:

1) Uninstal any previously installed version of ARWordReport form Delphi
(Delphi Menu - Components - Install Packages.. then select
"ARWordReport" and press "Remove" button).
2) Close Delphi.
3) Install ARWordReport by executing arwordreport**.exe or manually with *.dpk file.
4) Run Delphi.

=========================================================

